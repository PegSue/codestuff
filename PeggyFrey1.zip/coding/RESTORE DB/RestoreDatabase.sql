RESTORE DATABASE [ssnet_20140225]
   FROM DISK = 'D:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Backup\ssnet_backup_2014_02_25_220051_5426903.bak'
   WITH MOVE 'SS30v2_Data' TO 'D:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Data\ssnet_20140225.mdf',
   MOVE 'SS30v2_Log' TO 'D:\Program Files\Microsoft SQL Server\MSSQL11.MSSQLSERVER\MSSQL\Data\ssnet_20140225_log.ldf';
GO